<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

    
    <?php
        if(isset($error)){
            echo $error;
        }
    ?>
    <div class="container">
    <h3>Add Employee</h3>
        <form method="post" action="<?php echo base_url('employee/add_employee') ?>" enctype="multipart/form-data">

        <div class="form-group">
            <label for="first_name">First Name</label>
            <input type="text" class="form-control" name="first_name" id="first_name" value="<?php echo set_value('first_name'); ?>">
            <?php echo form_error('first_name','<div class = "text-danger">','</div>'); ?>
        </div><br>

        <div class="form-group">
            <label for="last_name">Last Name</label>
            <input type="text" class="form-control" name="last_name" id="last_name" value="<?php echo set_value('last_name'); ?>">
            <?php echo form_error('last_name','<div class = "text-danger">','</div>'); ?>
        </div><br>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" name="email" id="email" value="<?php echo set_value('email'); ?>">
            <?php echo form_error('email','<div class = "text-danger">','</div>'); ?>
        </div><br>

        <div class="row">
            <div class="form-group col-md-3">
                <label for="country_code">Country Code</label>
                <select class="form-control" id="country_code" name="country_code">
                    <option value="+1">+1 US</option>
                    <option value="+91">+91 India</option>
                </select>
            </div>
            <div class="form-group col-md-9">
                <label for="mobile_number">Mobile Number</label>
                <input type="number" class="form-control" name="mobile_number" id="mobile_number" value="<?php echo set_value('mobile_number'); ?>" maxlength="10" minlength="10">
                <?php echo form_error('mobile_number','<div class = "text-danger">','</div>'); ?>
            </div>
        </div><br>

        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" class="form-control" name="address" id="address" value="<?php echo set_value('address'); ?>">
            <?php echo form_error('address','<div class = "text-danger">','</div>'); ?>
        </div><br>

        <div class="form-group">
            <label for="gender">Gender</label>
            <div class="form-check form-check-inline">
                <input type="radio" class="form-check-input" name="gender" id="male" value="male" <?php echo set_radio('gender','male'); ?>>
                <label class="form-check-label" for="male">Male</label>
            </div>
            <div class="form-check form-check-inline">
                <input type="radio" class="form-check-input" name="gender" id="female" value="female" <?php echo set_radio('gender','female'); ?>>
                <label class="form-check-label" for="female">Female</label>
            </div>
            <div class="form-check form-check-inline">
                <input type="radio" class="form-check-input" name="gender" id="other" value="other" <?php echo set_radio('gender','other'); ?>>
                <label class="form-check-label" for="other">Other</label>
            </div>
            <?php echo form_error('gender','<div class = "text-danger">','</div>'); ?>
        </div><br>

        <div class="form-group">
            <label for="hobby">Hobby</label>
            <div class="form-check form-check-inline">
                <input type="checkbox" class="form-check-input" name="hobby[]" id="music" value="music" <?php echo set_checkbox('hobby[]','music'); ?>>
                <label class="form-check-label" for="music">Music</label>
            </div>
            <div class="form-check form-check-inline">
                <input type="checkbox" class="form-check-input" name="hobby[]" id="reading" value="reading" <?php echo set_checkbox('hobby[]','reading'); ?>>
                <label class="form-check-label" for="reading">Reading</label>
            </div>
            <div class="form-check form-check-inline">
                <input type="checkbox" class="form-check-input" name="hobby[]" id="sports" value="sports" <?php echo set_checkbox('hobby[]','sports'); ?>>
                <label class="form-check-label" for="sports">Sports</label>
            </div>
            <?php echo form_error('hobby[]','<div class = "text-danger">','</div>'); ?>
        </div><br>

        <div class="form-group">
            <label for="photo">Photo</label>
            <input type="file" accept="image/*" class="form-control" name="photo" id="photo" value="<?php echo set_value('photo'); ?>">
            <?php echo form_error('photo','<div class = "text-danger">','</div>'); ?>
        </div><br>

        <button type="submit" class="btn btn-primary">Submit</button>
        <a href="<?php echo base_url('employee') ?>" class="btn btn-info">Back</button>
    
    
        </form>
    </div>
    
</body>
</html>