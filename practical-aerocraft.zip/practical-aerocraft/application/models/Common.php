<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common extends CI_Model {

	public function __construct()
	{
		parent::__construct();
    }

    public function insert_data($data,$tablename){
        if($this->db->insert($tablename,$data)){
            $inserted_id = $this->db->insert_id();
            return $inserted_id;
        }else{
            return false;
        }
    }

    public function count_all(){
        $this->db->where('is_deleted','0');
        return $this->db->count_all('employees');
    }

    public function get_employess_data($search,$order,$order_dir){
        $this->db->select('*');
        $this->db->where('is_deleted','0');
        $this->db->from('employees');

        if(!empty($search)){
            $this->db->group_start();
            $this->db->like('first_name',$search);
            $this->db->or_like('last_name',$search);
            $this->db->or_like('email',$search);
            $this->db->or_like('mobile_number',$search);
            $this->db->or_like('address',$search);
            $this->db->or_like('gender',$search);
            $this->db->or_like('hobby',$search);
            $this->db->or_like('created_date',$search);
            $this->db->group_end();
        }

        $this->db->order_by($order,$order_dir);
        return $this->db->get()->result_array();
    }

    public function getdata_using_condition($tablename, $condition_array = array(), $data = '*', $sortby = '', $orderby = '', $limit = '', $offset = '', $join_str = array(), $groupby = '')
    {
        $this->db->select($data);
        $this->db->from($tablename);

        //if join_str array is not empty then implement the join query
        if (!empty($join_str)) {
            foreach ($join_str as $join) {
                if (!isset($join['join_type'])) {
                    $this->db->join($join['table'], $join['join_table_id'] . '=' . $join['from_table_id']);
                } else {
                    $this->db->join($join['table'], $join['join_table_id'] . '=' . $join['from_table_id'], $join['join_type']);
                }
            }
        }

        //condition array pass to where condition
        $this->db->where($condition_array);

        //Setting Limit for Paging
        if ($limit != '' && $offset == 0) {
            $this->db->limit($limit);
        } else if ($limit != '' && $offset != 0) {
            $this->db->limit($limit, $offset);
        }
        if ($groupby != '') {
            $this->db->group_by($groupby);
        }
        //order by query
        if ($sortby != '' && $orderby != '') {
            $this->db->order_by($sortby, $orderby);
        }

        $query = $this->db->get();

        //if limit is empty then returns total count
        if ($limit == '') {
            $query->num_rows();
        }
        //if limit is not empty then return result array
        return $query->result_array();
    }

    public function update_data($data,$tablename,$columname,$columnid){
        $this->db->where($columname,$columnid);
        if($this->db->update($tablename,$data)){
            return true;
        }else{
            return false;
        }
    }

}

?>