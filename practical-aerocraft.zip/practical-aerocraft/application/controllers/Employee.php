<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends MX_Controller {
    private $data;
	public function __construct()
	{
		parent::__construct();
        date_default_timezone_set("Asia/Calcutta");
    }

    public function index(){
        $this->load->view('employee/employee_list');
    }


    public function get_data(){
        $columns = array(
            0 => 'first_name',
            1 => 'last_name',
            2 => 'email',
            3 => 'mobile_number',
            4 => 'address',
            5 => 'gender',
            6 => 'hobby',
            7 => 'photo',
            8 => 'created_date',
            9 => 'Action',
        );

        $search = array();
        if(isset($_POST["search"]["value"]) && !empty($_POST["search"]["value"])){
            $search = $_POST["search"]["value"];
        }


        $order = array();
        if(isset($_POST["order"]) && !empty($_POST["search"])){
            $order = $columns[$_POST["order"][0]['column']];
            $order_dir = $columns[$_POST["order"][0]['dir']];
        }else{
            $order = 'id';
            $order_dir = 'asc';
        }

        $recordstotal = $this->common->count_all();
        
        $recordsFiltered = $recordstotal;
        $emoployess = $this->common->get_employess_data($search,$order,$order_dir);
        $final_data = array();
        foreach ($emoployess as $post) {
            $emoploye_id = $post['id'];
            $data_['first_name'] = $post['first_name'];
            $data_['last_name'] = $post['last_name'];
            $data_['email'] = $post['email'];
            $data_['mobile_number'] = $post['mobile_number'];
            $data_['address'] = wordwrap($post['address'],15,"<br>\n");
            $data_['gender'] = $post['gender'];
            $data_['hobby'] = $post['hobby'];
            $data_['photo'] = '<img src="'.base_url("uploads/".$post['photo']).'" style="width:50px;height:50px;">';
            $data_['created_date'] = $post['created_date'];
            $data_['Action'] = '<button onclick="edit_employee('.$emoploye_id.')">Edit</button>
            <button onclick="delete_employee('.$emoploye_id.')">Delete</button>';

            $final_data[] = $data_;
        }

        $return_data = array(
            // "draw" => $_POST['draw'],
            "recordsTotal" => $recordstotal,
            "recordsFiltered" => $recordsFiltered,
            "data" => $final_data
        );

        echo json_encode($return_data);
    }

    public function add(){
        $this->load->view('employee/add_employee');
    }


    public function add_employee(){
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('mobile_number', 'Mobile Number', 'trim|required|numeric|exact_length[10]');
        $this->form_validation->set_rules('address', 'Address', 'trim|required');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required');
        $this->form_validation->set_rules('hobby[]', 'Hobby', 'trim|required');

        if(empty($_FILES['photo']['name'])){
            $this->form_validation->set_rules('photo', 'Photo', 'required');
        }

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('employee/add_employee');
        }else{
            $config['upload_path'] = FCPATH.'uploads';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = 2000;
            $config['max_width'] = 1500;
            $config['max_height'] = 1500;

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('photo')) {
                $error = array('error' => $this->upload->display_errors());

                $this->load->view('employee/add_employee',$error);
            } else {
                $data = $this->upload->data();
                $insert_array = array(
                    'first_name' => $this->input->post('first_name'),
                    'last_name' => $this->input->post('last_name'),
                    'email' => $this->input->post('email'),
                    'mobile_country_code' => $this->input->post('country_code'),
                    'mobile_number' => $this->input->post('mobile_number'),
                    'address' => $this->input->post('address'),
                    'gender' => $this->input->post('gender'),
                    'hobby' => implode(', ',$this->input->post('hobby')),
                    'photo' => $data['file_name'],
                    'created_date' => date('Y-m-d H:i:s')
                );
                $insert_data =  $this->common->insert_data($insert_array,'employees');
                if($insert_data){
                    $this->session->set_flashdata('SUCCESS','Employee Data Added Successfully');
                    redirect('employee');
                }else{
                    unlink($config['upload_path'].$data['file_name']);
                    $this->session->set_flashdata('FAIL','Something Went Wrong');
                    redirect('employee');
                }
            }
        }
    }

    public function edit($id = ''){
        $data_employee = '*';
        $get_data = $this->common->getdata_using_condition('employees', $condition_array_product = array('id' => $id,'is_deleted' => '0'), $data_employee, $sortby = '', $orderby = '', $limit = '', $offset = '', $join_str = array(), $groupby = '');
        if(count($get_data) > 0){
            $this->data['existing_hobbies'] = explode(', ',$get_data[0]['hobby']);
            $this->data['employess'] = $get_data;
            $this->load->view('employee/edit_employee',$this->data);
        }else{
            $this->session->set_flashdata('FAIL','No Data Found');
            redirect('employee');
        }
        
    }

    public function edit_employee(){

        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('mobile_number', 'Mobile Number', 'trim|required|numeric|exact_length[10]');
        $this->form_validation->set_rules('address', 'Address', 'trim|required');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required');
        $this->form_validation->set_rules('hobby[]', 'Hobby', 'trim|required');

        $emoploye_id = $this->input->post('employee_id');
        if($emoploye_id){
            $data_employee = '*';
            $this->data['employess'] = $this->common->getdata_using_condition('employees', $condition_array_product = array('id' => $emoploye_id,'is_deleted' => '0'), $data_employee, $sortby = '', $orderby = '', $limit = '', $offset = '', $join_str = array(), $groupby = '');
            $this->data['existing_hobbies'] = explode(', ',$this->data['employess'][0]['hobby']);
            if ($this->form_validation->run() == FALSE) {
                $this->load->view('employee/edit_employee',$this->data);
            }else{
                if(empty($_FILES['photo']['name'])){
                    $update_data = array(
                        'first_name' => $this->input->post('first_name'),
                        'last_name' => $this->input->post('last_name'),
                        'email' => $this->input->post('email'),
                        'mobile_country_code' => $this->input->post('country_code'),
                        'mobile_number' => $this->input->post('mobile_number'),
                        'address' => $this->input->post('address'),
                        'gender' => $this->input->post('gender'),
                        'hobby' => implode(', ',$this->input->post('hobby')),
                    );
                }else{
                    $config['upload_path'] = FCPATH.'uploads';
                    $config['allowed_types'] = 'gif|jpg|png';
                    $config['max_size'] = 2000;
                    $config['max_width'] = 1500;
                    $config['max_height'] = 1500;
        
                    $this->load->library('upload', $config);

                    if (!$this->upload->do_upload('photo')) {
                        $this->data['error'] = array('error' => $this->upload->display_errors());
                        $this->load->view('employee/edit_employee',$this->data);
                    } else {
                        $data = $this->upload->data();
                        $update_data = array(
                            'first_name' => $this->input->post('first_name'),
                            'last_name' => $this->input->post('last_name'),
                            'email' => $this->input->post('email'),
                            'mobile_country_code' => $this->input->post('country_code'),
                            'mobile_number' => $this->input->post('mobile_number'),
                            'address' => $this->input->post('address'),
                            'gender' => $this->input->post('gender'),
                            'hobby' => implode(', ',$this->input->post('hobby')),
                            'photo' => $data['file_name'],
                        );
                    }
                }
                $update_data_db = $this->common->update_data($update_data,'employees','id',$emoploye_id);
                if($update_data_db){
                    $this->session->set_flashdata('SUCCESS','Employee Data Updated Successfully');
                    redirect('employee');
                }else{
                    $this->session->set_flashdata('FAIL','Something Went Wrong');
                    redirect('employee');
                }
            }
        }else{
            $this->session->set_flashdata('FAIL','Something Went Wrong');
            redirect('employee');
        }
        
    }

    public function delete_employee(){
        $emoploye_id = $this->input->post('employee_id');
        if($emoploye_id){
            $update_data = array(
                'is_deleted' => '1',
            );
            $update_data_db = $this->common->update_data($update_data,'employees','id',$emoploye_id);
                if($update_data_db){
                    $this->session->set_flashdata('SUCCESS','Employee Data Delete Successfully');
                    redirect('employee');
                }else{
                    $this->session->set_flashdata('FAIL','Something Went Wrong');
                    redirect('employee');
                }
        }else{
            $this->session->set_flashdata('FAIL','Something Went Wrong');
            redirect('employee');
        }
    }

}

?>